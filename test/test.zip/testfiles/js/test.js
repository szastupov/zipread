var Foo = "Bar";

module.exports = {
	foo: Foo
};
